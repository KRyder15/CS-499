// Keep default rules minimal for this project
