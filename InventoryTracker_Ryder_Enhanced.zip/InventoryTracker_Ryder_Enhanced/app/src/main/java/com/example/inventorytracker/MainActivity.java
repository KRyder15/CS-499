package com.example.inventorytracker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Main inventory screen: shows items, supports add, button-driven search/filter, and logout.
 */
public class MainActivity extends AppCompatActivity implements ItemAdapter.Callbacks {

    private static final String PREFS_NAME = "auth_prefs";
    private static final String KEY_USERNAME = "username";

    private DatabaseHelper db;
    private ItemAdapter adapter;

    private EditText etName;
    private EditText etQty;
    private EditText etSearch;
    private Button btnAdd;
    private Button btnLogout;
    private Button btnSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        etName = findViewById(R.id.etName);
        etQty = findViewById(R.id.etQty);
        etSearch = findViewById(R.id.etSearch);
        btnAdd = findViewById(R.id.btnAdd);
        btnLogout = findViewById(R.id.btnLogout);
        btnSearch = findViewById(R.id.btnSearch);
        RecyclerView rv = findViewById(R.id.recyclerView);

        adapter = new ItemAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> addItemFromInput());

        btnLogout.setOnClickListener(v -> {
            // Clear saved login and return to login screen
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().remove(KEY_USERNAME).apply();
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });

        // Button-driven search: empty query shows all items
        btnSearch.setOnClickListener(v -> {
            String query = etSearch.getText().toString();
            adapter.filter(query);
        });

        // Initial load
        refreshItems();
    }

    private void addItemFromInput() {
        String name = etName.getText().toString().trim();
        String qtyStr = etQty.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyStr)) {
            Toast.makeText(this, "Enter name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int q;
        try {
            q = Integer.parseInt(qtyStr);
        } catch (NumberFormatException ex) {
            Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (q < 0) {
            Toast.makeText(this, "Quantity cannot be negative", Toast.LENGTH_SHORT).show();
            return;
        }

        long id = db.addItem(name, q);
        if (id == -1) {
            Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            return;
        }

        etName.setText("");
        etQty.setText("");

        // Clear search so the new item is always visible
        etSearch.setText("");

        refreshItems();
    }

    private void refreshItems() {
        Cursor c = db.getAllItems();
        List<Item> items = new ArrayList<>();
        if (c != null) {
            while (c.moveToNext()) {
                long id = c.getLong(0);
                String name = c.getString(1);
                int qty = c.getInt(2);
                items.add(new Item(id, name, qty));
            }
            c.close();
        }
        // Set full list into adapter; adapter will show all by default
        adapter.setItems(items);
    }

    // --- ItemAdapter.Callbacks ---

    @Override
    public void onUpdateQty(Item item, int newQty) {
        db.updateQty(item.id, newQty);
        refreshItems();
    }

    @Override
    public void onDelete(Item item) {
        db.deleteItem(item.id);
        refreshItems();
    }
}
