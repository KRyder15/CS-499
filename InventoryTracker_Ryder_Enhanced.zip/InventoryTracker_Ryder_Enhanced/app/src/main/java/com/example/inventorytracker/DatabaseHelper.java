package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 2;

    public static final String T_USERS = "users";
    public static final String T_INV = "inventory";

    public DatabaseHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Simple credential store for demo purposes
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL" +
                ");");

        db.execSQL("CREATE TABLE " + T_INV + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "qty INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER DEFAULT (strftime('%s','now'))" +
                ");");

        // Seed with a default user for easier grading
        ContentValues cv = new ContentValues();
        cv.put("username", "admin");
        cv.put("password", "password");
        db.insert(T_USERS, null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_INV);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }

    // --- Authentication helpers ---

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        long id = db.insert(T_USERS, null, cv);
        return id != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_USERS,
                new String[]{"id"},
                "username=? AND password=?",
                new String[]{username, password},
                null, null, null
        );
        boolean ok = c != null && c.moveToFirst();
        if (c != null) c.close();
        return ok;
    }

    // --- Inventory helpers ---

    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("qty", qty);
        return db.insert(T_INV, null, cv);
    }

    public int updateQty(long id, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("qty", qty);
        return db.update(T_INV, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_INV, "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(
                "SELECT id, name, qty, created_at FROM " + T_INV + " ORDER BY created_at DESC",
                null
        );
    }
}
