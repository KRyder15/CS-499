package com.example.inventorytracker;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView adapter for inventory items with in-memory search filtering.
 */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {

    public interface Callbacks {
        void onUpdateQty(Item item, int newQty);
        void onDelete(Item item);
    }

    private final Callbacks callbacks;
    private final List<Item> allItems = new ArrayList<>();
    private final List<Item> visibleItems = new ArrayList<>();

    public ItemAdapter(Callbacks callbacks) {
        this.callbacks = callbacks;
    }

    public void setItems(List<Item> items) {
        allItems.clear();
        visibleItems.clear();
        if (items != null) {
            allItems.addAll(items);
            visibleItems.addAll(items);
        }
        notifyDataSetChanged();
    }

    /**
     * Simple case-insensitive name filter.
     */
    public void filter(String query) {
        visibleItems.clear();
        if (query == null || query.trim().isEmpty()) {
            visibleItems.addAll(allItems);
        } else {
            String q = query.toLowerCase();
            for (Item it : allItems) {
                if (it.name.toLowerCase().contains(q)) {
                    visibleItems.add(it);
                }
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Item it = visibleItems.get(position);
        h.name.setText(it.name);
        h.qty.setText(String.valueOf(it.qty));

        h.btnInc.setOnClickListener(v ->
                callbacks.onUpdateQty(it, it.qty + 1));

        h.btnDec.setOnClickListener(v ->
                callbacks.onUpdateQty(it, Math.max(0, it.qty - 1)));

        h.btnDel.setOnClickListener(v ->
                callbacks.onDelete(it));
    }

    @Override
    public int getItemCount() {
        return visibleItems.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView qty;
        final ImageButton btnInc;
        final ImageButton btnDec;
        final ImageButton btnDel;

        VH(View v) {
            super(v);
            name = v.findViewById(R.id.tvName);
            qty = v.findViewById(R.id.tvQty);
            btnInc = v.findViewById(R.id.btnInc);
            btnDec = v.findViewById(R.id.btnDec);
            btnDel = v.findViewById(R.id.btnDel);
        }
    }
}
