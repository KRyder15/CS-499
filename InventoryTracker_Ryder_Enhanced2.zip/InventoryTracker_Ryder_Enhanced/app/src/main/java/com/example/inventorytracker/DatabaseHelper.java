package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 3;

    public static final String T_USERS = "users";
    public static final String T_INV = "inventory";

    public DatabaseHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // User table with salted+hashed passwords for safer credential storage
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL," +
                "salt TEXT NOT NULL" +
                ");");

        db.execSQL("CREATE TABLE " + T_INV + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "qty INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER DEFAULT (strftime('%s','now'))" +
                ");");

        // Optional indexes to keep lookups fast as data grows
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_users_username ON " + T_USERS + " (username);");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_inventory_name ON " + T_INV + " (name);");

        // Seed with a default user for easier grading (hashed + salted password)
        ContentValues cv = new ContentValues();
        String defaultSalt = generateSalt();
        String defaultHash = hashPassword("password", defaultSalt);
        cv.put("username", "admin");
        cv.put("password", defaultHash);
        cv.put("salt", defaultSalt);
        db.insert(T_USERS, null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_INV);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }


// --- Password hashing helpers ---

private static final int SALT_LENGTH_BYTES = 16;

private static String generateSalt() {
    SecureRandom random = new SecureRandom();
    byte[] salt = new byte[SALT_LENGTH_BYTES];
    random.nextBytes(salt);
    return bytesToHex(salt);
}

private static String hashPassword(String password, String saltHex) {
    try {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        // Combine salt and password to build the hash
        md.update(saltHex.getBytes(StandardCharsets.UTF_8));
        md.update(password.getBytes(StandardCharsets.UTF_8));
        byte[] digest = md.digest();
        return bytesToHex(digest);
    } catch (NoSuchAlgorithmException e) {
        // SHA-256 should always be available on Android; if not, fail fast.
        throw new RuntimeException("Unable to hash password", e);
    }
}

private static String bytesToHex(byte[] bytes) {
    StringBuilder sb = new StringBuilder(bytes.length * 2);
    for (byte b : bytes) {
        sb.append(String.format("%02x", b));
    }
    return sb.toString();
}

    // --- Authentication helpers ---

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        String salt = generateSalt();
        String hash = hashPassword(password, salt);
        cv.put("username", username);
        cv.put("password", hash);
        cv.put("salt", salt);
        long id = db.insert(T_USERS, null, cv);
        return id != -1;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                T_USERS,
                new String[]{"password", "salt"},
                "username=?",
                new String[]{username},
                null, null, null
        );
        if (c != null && c.moveToFirst()) {
            String storedHash = c.getString(0);
            String salt = c.getString(1);
            String candidateHash = hashPassword(password, salt);
            c.close();
            return storedHash != null && storedHash.equals(candidateHash);
        }
        if (c != null) {
            c.close();
        }
        return false;
    }

    // --- Inventory helpers ---

    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("qty", qty);
        return db.insert(T_INV, null, cv);
    }

    public int updateQty(long id, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("qty", qty);
        return db.update(T_INV, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_INV, "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(
                "SELECT id, name, qty, created_at FROM " + T_INV + " ORDER BY created_at DESC",
                null
        );
    }
}
