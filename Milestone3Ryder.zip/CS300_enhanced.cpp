// ProjectTwo.cpp - ABCU Advising Assistance Program (enhanced usability)

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

struct Course {
    std::string number;                 // e.g., "CSCI200"
    std::string title;                  // e.g., "Data Structures"
    std::vector<std::string> prereqs;   // e.g., {"CSCI100", "MATH201"}
};

static inline std::string trim(const std::string& s) {
    size_t b = 0, e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return s.substr(b, e - b);
}

static inline std::string toUpper(std::string s) {
    for (auto& ch : s) {
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    }
    return s;
}

// Unquote a string if surrounded by matching single or double quotes.
// Also replaces "\ " sequences (from shell-escaped inputs) with literal spaces.
static inline std::string normalizeFilename(std::string s) {
    s = trim(s);
    if (s.size() >= 2) {
        if ((s.front() == '"' && s.back() == '"') ||
            (s.front() == '\'' && s.back() == '\'')) {
            s = s.substr(1, s.size() - 2);
        }
    }

    // Unescape "\ " -> " "
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\\' && i + 1 < s.size() && s[i + 1] == ' ') {
            out.push_back(' ');
            ++i;
        } else {
            out.push_back(s[i]);
        }
    }
    return trim(out);
}

static inline std::vector<std::string> split(const std::string& line, char delim = ',') {
    std::vector<std::string> out;
    std::string field;
    std::istringstream ss(line);
    while (std::getline(ss, field, delim)) {
        out.push_back(trim(field));
    }
    return out;
}

bool loadCatalogFromFile(const std::string& filename,
                         std::unordered_map<std::string, Course>& catalog,
                         std::string& error) {
    std::ifstream fin(filename);
    if (!fin) {
        error = "Error: Unable to open file '" + filename + "'.";
        return false;
    }

    std::unordered_map<std::string, Course> temp;
    std::string line;
    size_t lineNo = 0;

    while (std::getline(fin, line)) {
        ++lineNo;
        if (trim(line).empty()) continue;

        auto fields = split(line, ',');
        if (fields.size() < 2) {
            std::ostringstream oss;
            oss << "Error: Malformed line " << lineNo
                << " (needs course number and title).";
            error = oss.str();
            return false;
        }

        Course c;
        c.number = toUpper(fields[0]);
        c.title  = fields[1];

        for (size_t i = 2; i < fields.size(); ++i) {
            if (!fields[i].empty()) {
                c.prereqs.push_back(toUpper(fields[i]));
            }
        }

        temp[c.number] = std::move(c);
    }

    catalog.swap(temp);
    return true;
}

void printCourseList(const std::unordered_map<std::string, Course>& catalog) {
    if (catalog.empty()) {
        std::cout << "No data loaded. Please load the data structure first (option 1).\n";
        return;
    }

    std::vector<std::string> keys;
    keys.reserve(catalog.size());
    for (const auto& kv : catalog) {
        keys.push_back(kv.first);
    }

    std::sort(keys.begin(), keys.end());

    for (const auto& k : keys) {
        const auto& c = catalog.at(k);
        std::cout << c.number << ", " << c.title << "\n";
    }
}

void printCourseInfo(const std::unordered_map<std::string, Course>& catalog,
                     std::string queryRaw) {
    if (catalog.empty()) {
        std::cout << "No data loaded. Please load the data structure first (option 1).\n";
        return;
    }

    std::string query = toUpper(trim(queryRaw));

    auto it = catalog.find(query);
    if (it != catalog.end()) {
        const Course& c = it->second;
        std::cout << c.number << ", " << c.title << "\n";

        if (c.prereqs.empty()) {
            std::cout << "Prerequisites: None\n";
        } else {
            std::cout << "Prerequisites: ";
            for (size_t i = 0; i < c.prereqs.size(); ++i) {
                const std::string& pre = c.prereqs[i];
                auto jt = catalog.find(pre);
                if (jt != catalog.end()) {
                    std::cout << jt->second.number << " (" << jt->second.title << ")";
                } else {
                    std::cout << pre << " (not found)";
                }
                if (i + 1 < c.prereqs.size()) std::cout << ", ";
            }
            std::cout << "\n";
        }
        return;
    }

    // Not found: suggest close matches
    std::vector<std::string> suggestions;
    for (const auto& kv : catalog) {
        const std::string& num = kv.first;
        const std::string& title = kv.second.title;

        if (num.find(query) != std::string::npos) {
            suggestions.push_back(num);
        } else {
            // case-insensitive contains on title
            std::string upTitle = title;
            for (auto& ch : upTitle) {
                ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
            }
            if (upTitle.find(query) != std::string::npos) {
                suggestions.push_back(num);
            }
        }
    }

    std::cout << "Course '" << queryRaw << "' not found.\n";
    if (!suggestions.empty()) {
        std::sort(suggestions.begin(), suggestions.end());
        suggestions.erase(std::unique(suggestions.begin(), suggestions.end()),
                          suggestions.end());

        std::cout << "Did you mean: ";
        for (size_t i = 0; i < suggestions.size(); ++i) {
            std::cout << suggestions[i];
            if (i + 1 < suggestions.size()) std::cout << ", ";
        }
        std::cout << "?\n";
    }
}

int readIntChoice() {
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    if (line.empty()) return -1;
    for (char ch : line) {
        if (!std::isdigit(static_cast<unsigned char>(ch))) return -1;
    }
    try {
        return std::stoi(line);
    } catch (...) {
        return -1;
    }
}

int main() {
    std::unordered_map<std::string, Course> catalog;
    bool running = true;

    std::cout << "Welcome to the ABCU Advising Assistance Program\n";

    while (running) {
        std::cout << "\nMenu:\n";
        std::cout << "  1. Load Data Structure\n";
        std::cout << "  2. Print Course List\n";
        std::cout << "  3. Print Course\n";
        std::cout << "  9. Exit\n";
        std::cout << "Enter choice: ";

        int choice = readIntChoice();

        switch (choice) {
            case 1: {
                std::cout << "Enter file name to load (e.g., ABCU_Advising_Program_Input.csv): ";
                std::string filename;
                std::getline(std::cin, filename);
                filename = normalizeFilename(filename);

                std::string error;
                if (loadCatalogFromFile(filename, catalog, error)) {
                    std::cout << "Data loaded successfully from '" << filename
                              << "'. Courses loaded: " << catalog.size() << "\n";
                } else {
                    std::cout << error << "\n";
                }
                break;
            }
            case 2:
                printCourseList(catalog);
                break;
            case 3: {
                std::cout << "Enter course number: ";
                std::string courseNum;
                std::getline(std::cin, courseNum);
                printCourseInfo(catalog, courseNum);
                break;
            }
            case 9:
                std::cout << "Goodbye!\n";
                running = false;
                break;
            default:
                std::cout << "Invalid selection. Please choose 1, 2, 3, or 9.\n";
        }
    }

    return 0;
}