// ProjectTwo.cpp - ABCU Advising Assistance Program 

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct Course {
    std::string number;               // e.g., "CSCI200"
    std::string title;                // e.g., "Data Structures"
    std::vector<std::string> prereqs; // e.g., {"CSCI100", "MATH201"}
};

// Optional helper: convert a string to uppercase (simple, no trimming, no quoting logic)
std::string toUpper(const std::string& s) {
    std::string out = s;
    for (char& ch : out) {
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    }
    return out;
}

// Load courses from a CSV file into a vector
void loadCourses(const std::string& filename, std::vector<Course>& courses) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "Error: Could not open file " << filename << "\n";
        return;
    }

    courses.clear();

    std::string line;
    while (std::getline(file, line)) {
        if (line.empty()) {
            continue;
        }

        std::stringstream ss(line);
        std::string num;
        std::string title;

        // First field: course number
        if (!std::getline(ss, num, ',')) {
            continue;
        }

        // Second field: course title
        if (!std::getline(ss, title, ',')) {
            continue;
        }

        Course c;
        c.number = toUpper(num);
        c.title = title;

        // Remaining fields: prerequisites (if any)
        std::string pre;
        while (std::getline(ss, pre, ',')) {
            if (!pre.empty()) {
                c.prereqs.push_back(toUpper(pre));
            }
        }

        courses.push_back(c);
    }

    std::cout << "Loaded " << courses.size() << " courses from " << filename << "\n";
}

// Print course list in alphanumeric order by course number
void printCourseList(const std::vector<Course>& courses) {
    if (courses.empty()) {
        std::cout << "No course data loaded. Please load data first.\n";
        return;
    }

    // Make a copy so we can sort without changing the original ordering
    std::vector<Course> sorted = courses;
    std::sort(sorted.begin(), sorted.end(),
              [](const Course& a, const Course& b) {
                  return a.number < b.number;
              });

    std::cout << "\nCourse List:\n";
    for (const Course& c : sorted) {
        std::cout << c.number << ", " << c.title << "\n";
    }
}

// Find a course by number (linear search)
const Course* findCourse(const std::vector<Course>& courses, const std::string& courseNum) {
    std::string target = toUpper(courseNum);
    for (const Course& c : courses) {
        if (c.number == target) {
            return &c;
        }
    }
    return nullptr;
}

// Print a single course and its prerequisites
void printCourse(const std::vector<Course>& courses) {
    if (courses.empty()) {
        std::cout << "No course data loaded. Please load data first.\n";
        return;
    }

    std::cout << "Enter course number: ";
    std::string courseNum;
    std::cin >> courseNum;

    const Course* c = findCourse(courses, courseNum);
    if (c == nullptr) {
        std::cout << "Course " << courseNum << " not found.\n";
        return;
    }

    std::cout << c->number << ", " << c->title << "\n";

    if (c->prereqs.empty()) {
        std::cout << "Prerequisites: None\n";
    } else {
        std::cout << "Prerequisites: ";
        for (size_t i = 0; i < c->prereqs.size(); ++i) {
            std::cout << c->prereqs[i];
            if (i + 1 < c->prereqs.size()) {
                std::cout << ", ";
            }
        }
        std::cout << "\n";
    }
}

// Simple menu loop using basic std::cin >> choice
int main() {
    std::vector<Course> courses;
    bool running = true;

    std::cout << "Welcome to the ABCU Advising Assistance Program\n";

    while (running) {
        std::cout << "\nMenu:\n";
        std::cout << "  1. Load Data Structure\n";
        std::cout << "  2. Print Course List\n";
        std::cout << "  3. Print Course\n";
        std::cout << "  9. Exit\n";
        std::cout << "Enter choice: ";

        int choice;
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::string filename;
                std::cout << "Enter file name (e.g., ABCU_Advising_Program_Input.csv): ";
                std::cin >> filename;
                loadCourses(filename, courses);
                break;
            }
            case 2:
                printCourseList(courses);
                break;
            case 3:
                printCourse(courses);
                break;
            case 9:
                std::cout << "Goodbye!\n";
                running = false;
                break;
            default:
                std::cout << "Invalid selection. Please choose 1, 2, 3, or 9.\n";
        }
    }

    return 0;
}